The following is a list of professional events on Machine Learning and Artificial Intelligence

## Machine Learning and Artificial Intelligence

* [AI & ML Events](https://aiml.events) - The best upcoming hand-picked conferences and exhibitions in the field of artificial intelligence and machine learning
* [Codementor Events](https:///www.codementor.io/events) - The best developer-focused free virtual events platform, ranging from technical to career related topics